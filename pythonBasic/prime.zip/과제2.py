def do_sum():
  num = []
  for i in range(5):
    inp = input("Type the number: ")
    num.append(int(inp))

  sum = 0
  for i in num:
    sum += i
    
  print(sum)