class Employee:

  def __init__(self, name="NULL", salary=0):
    
  def get_name(self):
    
  def get_salary(self):
    
  def get_emp_cnt(self):

if __name__ == :
  Company = []
  data = {'Alcie':200, 'Bob':300, 'Mike':100}

  for key in data:
    emp = Employee(key, data[key])
    Company.append(emp)

  print("Total number of Employee: ", Company[0].get_emp_cnt())

  max_salary = 0
  max_name = ""
  for emp in Company:
    if int(emp.get_salary()) > max_salary:
      max_name = emp.get_name()
      max_salary = int(emp.get_salary())
  
  print("Max-salary employee: ", max_name, max_salary)