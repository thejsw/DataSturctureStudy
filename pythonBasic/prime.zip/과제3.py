phonebook = dict()

def insert(name, number):
  phonebook[name] = number
  
def delete(name):
  return phonebook.pop(name, -1)

def search(name):
  if name in phonebook:
    number = phonebook[name]
    return number

def scan():

  if __name__ == :
    while 1:
      choice = input("Select the menu. 1:insert, 2:delete, 3:search, 4:scan, 5:quit")
      if choice == "1":
        name = input("Type your name: ")
        number = input("Type your number: ")
      elif choice == "2":
        name = input("Type your name: ")
        delete(name)
      elif choice == "3":
        name = input("Type your name: ")
        number = search(name)
        print(number)
      elif choice == "4":
        scan()
      elif choice == "5":
        break
      else:
        print("Wrong number")
        