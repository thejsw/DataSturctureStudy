def is_included (word, sentence):
  if word in sentence:
    return "true"
  else:
    return "false"

print(is_included("love", "i love you"))